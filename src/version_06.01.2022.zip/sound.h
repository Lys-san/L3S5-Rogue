/* Auteurs : Nicolas Mazeyrac, Lysandre Macke
 * Creation : 26/11/2021
 * Modification : 30/11/2021*/

/*Bibliothèque générale*/
#include <MLV/MLV_all.h>

/*Bibliothèque interne*/

#ifndef __SOUND__
#define __SOUND__

    /*Define*/


    /*Struct*/
    

    /*Functions*/

    void playButtonSound_1();

    void playButtonSound_2();

#endif